import React from 'react'

function AddPost() {
  return (
    <div>
      <h1>this is Add post page</h1>
     
    </div>
  )
}

export default AddPost

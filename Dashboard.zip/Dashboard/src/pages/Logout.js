import React from 'react'

function Logout() {
  return (
    <div>
      You Are Logout SuccessFully
    </div>
  )
}

export default Logout

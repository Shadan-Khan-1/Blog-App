import React from 'react'

function About() {
  return (
    <div>
      About Something Blog App
    </div>
  )
}

export default About

import React from 'react'

function Blogs() {
  return (
    <div>
      Here you can see all blog post 
    </div>
  )
}

export default Blogs
